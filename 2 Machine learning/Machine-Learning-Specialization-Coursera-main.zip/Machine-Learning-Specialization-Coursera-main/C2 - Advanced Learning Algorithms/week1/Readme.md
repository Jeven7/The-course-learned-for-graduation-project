### C2 - Week 1 Solutions 

<br/>

- [Practice quiz: Neural networks intuition](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/tree/main/C2%20-%20Advanced%20Learning%20Algorithms/week1/Practice%20quiz%20-%20Neural%20networks%20intuition)
- [Practice quiz: Neural network model](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/tree/main/C2%20-%20Advanced%20Learning%20Algorithms/week1/Practice%20quiz%20-%20Neural%20network%20model)
- [Practice quiz: TensorFlow implementation](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/tree/main/C2%20-%20Advanced%20Learning%20Algorithms/week1/Practice%20quiz%20-%20TensorFlow%20implementation)
- [Practice quiz : Neural Networks Implementation in Numpy](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/e5d6103f4bdf732390bd85aeb453002f276d8bf3/C2%20-%20Advanced%20Learning%20Algorithms/week1/Practice-Quiz-Neural-Networks-Implementation-in-python)
- [Optional Labs](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/794f84af434b89b90af8d21b25727661f71148d6/C2%20-%20Advanced%20Learning%20Algorithms/week1/optional-labs)
  - [Neurons and Layers](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/794f84af434b89b90af8d21b25727661f71148d6/C2%20-%20Advanced%20Learning%20Algorithms/week1/optional-labs/C2_W1_Lab01_Neurons_and_Layers.ipynb)
  - [Coffee Roasting](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/794f84af434b89b90af8d21b25727661f71148d6/C2%20-%20Advanced%20Learning%20Algorithms/week1/optional-labs/C2_W1_Lab02_CoffeeRoasting_TF.ipynb)
  - [Coffee Roasting Using Numpy](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/794f84af434b89b90af8d21b25727661f71148d6/C2%20-%20Advanced%20Learning%20Algorithms/week1/optional-labs/C2_W1_Lab03_CoffeeRoasting_Numpy.ipynb)
- [Programming Assignment](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/794f84af434b89b90af8d21b25727661f71148d6/C2%20-%20Advanced%20Learning%20Algorithms/week1/C2W1A1)
  - [Neural Networks for Binary Classification](https://github.com/greyhatguy007/Machine-Learning-Specialization-Coursera/blob/794f84af434b89b90af8d21b25727661f71148d6/C2%20-%20Advanced%20Learning%20Algorithms/week1/C2W1A1/C2_W1_Assignment.ipynb)
  