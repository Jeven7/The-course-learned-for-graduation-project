![](/C1%20-%20Supervised%20Machine%20Learning:%20Regression%20and%20Classification/week3/Practice%20quiz:%20Cost%20function%20for%20logistic%20regression/ss1.png)
